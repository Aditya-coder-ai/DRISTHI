-- Schema snapshot for corp_finance_db
CREATE TABLE employees (id INT PRIMARY KEY, name VARCHAR(100), salary DECIMAL(10,2));
CREATE TABLE customers (id INT PRIMARY KEY, name VARCHAR(100), balance DECIMAL(10,2));
CREATE TABLE transactions (id INT PRIMARY KEY, amount DECIMAL(10,2), status VARCHAR(20));
